Święty Kościół Katolicki — Adrian Żalejko
Wersja 3: responsywna, pełna szerokość, tylko nowy artykuł o Najświętszej Maryi Pannie.

Publikacja:
1. Rozpakuj ZIP.
2. W Netlify otwórz Deploys.
3. Wgraj zawartość tego folderu jako nowy deploy.

Struktura:
index.html
article-maryja.html
style.css
assets/maryja-hero.jpg
robots.txt
sitemap.xml
