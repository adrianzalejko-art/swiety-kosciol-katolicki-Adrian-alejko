PRZYWRÓCONA WERSJA V2

Ta paczka zawiera wersję strony opartą na wcześniejszej wersji V2:
- strona główna bez przebudowy,
- obraz strony głównej na pełną szerokość,
- obraz artykułu na stronie artykułu,
- grafika na stronie głównej prowadząca do artykułu,
- zachowany układ, kolorystyka i nawigacja tej wersji.

Do GitHub Pages należy wgrać zawartość tego archiwum do głównego katalogu repozytorium (root) i zatwierdzić zmiany.
